﻿# =========================================================
# Lenovo BIOS Update Script
# =========================================================

$BaseFolder = "C:\ProgramData\Company\LenovoBIOS"
$ExtractFolder = "$BaseFolder\BIOS_Extract"
$LogFile = "$BaseFolder\Update.log"

# =========================================================
# LOGGING
# =========================================================

if (!(Test-Path $BaseFolder)) {
    New-Item -Path $BaseFolder -ItemType Directory -Force | Out-Null
}

Function Write-Log {
    param(
        [string]$MessageType,
        [string]$Message
    )

    $Date = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $Line = "[$Date] [$MessageType] $Message"

    Add-Content -Path $LogFile -Value $Line
    Write-Host $Line
}

Write-Log -MessageType "INFO" -Message "Starting BIOS update process"

# =========================================================
# VALIDATE CONTINUE FILE
# =========================================================

$ContinueFile = "$ExtractFolder\BIOS_Update_Continue.txt"

if (!(Test-Path $ContinueFile)) {

    Write-Log -MessageType "ERROR" -Message "Continue file missing"
    Exit 1
}

Write-Log -MessageType "INFO" -Message "User approved BIOS update"

# =========================================================
# CHECK BIOS PASSWORD
# =========================================================

try {

    $PasswordState = Get-WmiObject `
        -Namespace root\wmi `
        -Class Lenovo_BiosPasswordSettings `
        -ErrorAction Stop

    if ($PasswordState.PasswordState -ne 0) {

        Write-Log -MessageType "ERROR" -Message "BIOS password detected"

        Exit 1
    }

}
catch {

    Write-Log -MessageType "WARN" -Message "Unable to determine BIOS password state"
}

# =========================================================
# CHECK AC POWER
# =========================================================

$Battery = Get-WmiObject Win32_Battery -ErrorAction SilentlyContinue

if ($Battery) {

    if ($Battery.BatteryStatus -ne 2) {

        Write-Log -MessageType "ERROR" -Message "AC adapter not connected"

        Exit 1
    }

    if ($Battery.EstimatedChargeRemaining -lt 50) {

        Write-Log -MessageType "ERROR" -Message "Battery below 50%"

        Exit 1
    }
}

Write-Log -MessageType "INFO" -Message "Power validation successful"

# =========================================================
# SUSPEND BITLOCKER
# =========================================================

try {

    $BLV = Get-BitLockerVolume -MountPoint $env:SystemDrive

    if ($BLV.ProtectionStatus -eq "On") {

        Suspend-BitLocker `
            -MountPoint $env:SystemDrive `
            -RebootCount 2 | Out-Null

        Write-Log -MessageType "SUCCESS" -Message "BitLocker suspended"
    }
    else {

        Write-Log -MessageType "INFO" -Message "BitLocker already suspended"
    }

}
catch {

    Write-Log -MessageType "ERROR" -Message "Failed suspending BitLocker"

    Exit 1
}

# =========================================================
# FIND FLASH UTILITY
# =========================================================

Write-Log -MessageType "INFO" -Message "Searching for Lenovo flash utility"

$FlashUtility = Get-ChildItem `
    -Path $ExtractFolder `
    -Recurse `
    -ErrorAction SilentlyContinue |
Where-Object {

    $_.Name -match 'WinFlash64.exe|winuptp.exe|flash.cmd'

} | Select-Object -First 1

if (!$FlashUtility) {

    Write-Log -MessageType "ERROR" -Message "No supported flash utility found"

    Exit 1
}

Write-Log -MessageType "INFO" -Message "Flash utility found: $($FlashUtility.FullName)"

# =========================================================
# EXECUTE BIOS UPDATE
# =========================================================

try {

    switch ($FlashUtility.Name.ToLower()) {

        "winflash64.exe" {

            $Args = "/quiet"
        }

        "winuptp.exe" {

            $Args = "/S"
        }

        "flash.cmd" {

            $Args = ""
        }

        default {

            Write-Log -MessageType "ERROR" -Message "Unknown flash utility"

            Exit 1
        }
    }

    Write-Log -MessageType "INFO" -Message "Executing BIOS update"

    $Process = Start-Process `
        -FilePath $FlashUtility.FullName `
        -ArgumentList $Args `
        -Wait `
        -PassThru `
        -WindowStyle Hidden

    Write-Log -MessageType "INFO" -Message "Exit code: $($Process.ExitCode)"

}
catch {

    Write-Log -MessageType "ERROR" -Message "Failed launching BIOS update"

    Exit 1
}

# =========================================================
# HANDLE EXIT CODES
# =========================================================

switch ($Process.ExitCode) {

    0 {

        Write-Log -MessageType "SUCCESS" -Message "BIOS update completed"

        Start-Sleep -Seconds 15

        Restart-Computer -Force
    }

    3010 {

        Write-Log -MessageType "SUCCESS" -Message "BIOS update requires reboot"

        Start-Sleep -Seconds 15

        Restart-Computer -Force
    }

    default {

        Write-Log -MessageType "ERROR" -Message "BIOS update failed"

        Exit 1
    }
}