﻿$Extract_Folder_Path = "C:\Windows\Temp\BIOS_Extract"
$Get_MTM = ((Get-CimInstance Win32_ComputerSystem).Model.SubString(0, 4)).Trim()
$Log_File = "$env:SystemDrive\Windows\Debug\Remediation_BIOS_Update_$Get_MTM.log"

Function Write_Log {
    param($Message_Type, $Message)
    $MyDate = "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)
    Add-Content $Log_File "$MyDate - $Message_Type : $Message"
    Write-Host "$MyDate - $Message_Type : $Message"
}

If (Test-Path "$Extract_Folder_Path\BIOS_Update_Continue.txt") {							
    Write_Log -Message_Type "INFO" -Message "User validated the update process"

    # Suspend BitLocker
    $BL = Get-BitLockerVolume -MountPoint $env:SystemDrive
    if ($BL.ProtectionStatus -eq "On") {
        Suspend-BitLocker -MountPoint $env:SystemDrive -RebootCount 1 | Out-Null
        Write_Log -Message_Type "SUCCESS" -Message "BitLocker suspended"
    }

    Set-Location $Extract_Folder_Path

    # ====================== AUTO DETECTION ======================
    $OriginalInstaller = Get-ChildItem "$Extract_Folder_Path\*.exe" | 
                         Where-Object { $_.Name -like "s0e*.exe" -or $_.Name -like "*BIOS*.exe" } | 
                         Select-Object -First 1

    $AFUWin = Test-Path "$Extract_Folder_Path\AFUWINx64.EXE"
    $WinUPTP = Test-Path "$Extract_Folder_Path\WINUPTP64.exe" -or (Test-Path "$Extract_Folder_Path\WINUPTP.exe")

    Write_Log -Message_Type "INFO" -Message "Detection: Original Installer = $([bool]$OriginalInstaller) | AFUWIN = $AFUWin | WINUPTP = $WinUPTP"

    # === Preferred Method: Original Installer (Capsule mode - most reliable on new machines) ===
    if ($OriginalInstaller) {
        Write_Log -Message_Type "INFO" -Message "Using Original Installer (Capsule mode): $($OriginalInstaller.Name)"
        
        $Result = Start-Process -FilePath $OriginalInstaller.FullName -ArgumentList "/silent", "/noreboot" -Wait -PassThru
        
        Write_Log -Message_Type "INFO" -Message "Installer Exit Code: $($Result.ExitCode)"
        
        if ($Result.ExitCode -in @(0, 3010)) {
            Write_Log -Message_Type "SUCCESS" -Message "BIOS update initiated successfully"
            Start-Sleep -Seconds 10
            Restart-Computer -Force
        } else {
            Write_Log -Message_Type "ERROR" -Message "Original installer failed with code $($Result.ExitCode)"
        }
    }
    # === Fallback 1: WINUPTP (older method) ===
    elseif ($WinUPTP) {
        $WinUPTPexe = if (Test-Path "$Extract_Folder_Path\WINUPTP64.exe") { "WINUPTP64.exe" } else { "WINUPTP.exe" }
        Write_Log -Message_Type "INFO" -Message "Using WINUPTP method"
        $Result = Start-Process -FilePath $WinUPTPexe -ArgumentList "-s" -Wait -PassThru
        Write_Log -Message_Type "INFO" -Message "WINUPTP Exit Code: $($Result.ExitCode)"
    }
    # === Fallback 2: AFUWINx64 (oldest method) ===
    elseif ($AFUWin) {
        Write_Log -Message_Type "INFO" -Message "Using AFUWINx64 fallback"
        $Result = Start-Process -FilePath ".\AFUWINx64.EXE" -ArgumentList "/b /p /r /s" -Wait -PassThru
        Write_Log -Message_Type "INFO" -Message "AFUWIN Exit Code: $($Result.ExitCode)"
    }
    else {
        Write_Log -Message_Type "ERROR" -Message "No valid BIOS installer found"
    }
}