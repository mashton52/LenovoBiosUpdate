﻿$Extract_Folder_Path = "C:\Windows\Temp\BIOS_Extract"

$Get_MTM = ((Get-CimInstance Win32_ComputerSystem).Model.SubString(0, 4)).Trim()
$Log_File = "$env:SystemDrive\Windows\Debug\Remediation_BIOS_Update_$Get_MTM.log"

Function Write_Log {
    param($Message_Type, $Message)
    $MyDate = "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)
    Add-Content $Log_File "$MyDate - $Message_Type : $Message"
    Write-Host "$MyDate - $Message_Type : $Message"
}

If (Test-Path "$Extract_Folder_Path\BIOS_Update_Continue.txt") {							
    Write_Log -Message_Type "INFO" -Message "User validated the update process"

    # Suspend BitLocker
    $BL = Get-BitLockerVolume -MountPoint $env:SystemDrive
    if ($BL.ProtectionStatus -eq "On") {
        Suspend-BitLocker -MountPoint $env:SystemDrive -RebootCount 1 | Out-Null
        Write_Log -Message_Type "SUCCESS" -Message "BitLocker suspended"
    }

    Set-Location $Extract_Folder_Path

    # Force use of the original installer (this is what we need)
    $OriginalInstaller = Get-ChildItem "*.exe" | Where-Object { $_.Name -like "s0e*.exe" } | Select-Object -First 1

    if ($OriginalInstaller) {
        Write_Log -Message_Type "INFO" -Message "Running Original BIOS Installer: $($OriginalInstaller.Name)"
        
        $Result = Start-Process -FilePath $OriginalInstaller.FullName -ArgumentList "/silent", "/noreboot" -Wait -PassThru -NoNewWindow
        
        Write_Log -Message_Type "INFO" -Message "Installer Exit Code: $($Result.ExitCode)"
        
        if ($Result.ExitCode -in @(0, 3010)) {
            Write_Log -Message_Type "SUCCESS" -Message "BIOS update started successfully - Rebooting now"
            Start-Sleep -Seconds 10
            Restart-Computer -Force
        } else {
            Write_Log -Message_Type "ERROR" -Message "Installer failed with code $($Result.ExitCode)"
        }
    }
    else {
        Write_Log -Message_Type "ERROR" -Message "Original BIOS installer not found"
    }
}