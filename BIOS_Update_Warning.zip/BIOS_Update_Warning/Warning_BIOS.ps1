﻿$Global:Current_Folder = Split-Path $MyInvocation.MyCommand.Path

[System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms') | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName('presentationframework') | Out-Null
[System.Reflection.Assembly]::LoadFrom("$Current_Folder\assembly\MahApps.Metro.dll") | Out-Null
[System.Reflection.Assembly]::LoadFrom("$Current_Folder\assembly\MahApps.Metro.IconPacks.dll") | Out-Null  

function LoadXml ($global:filename) {
    $XamlLoader = (New-Object System.Xml.XmlDocument)
    $XamlLoader.Load($filename)
    return $XamlLoader
}

$XamlMainWindow = LoadXml("$Current_Folder\Warning_BIOS.xaml")
$Reader = (New-Object System.Xml.XmlNodeReader $XamlMainWindow)
$Form = [Windows.Markup.XamlReader]::Load($Reader)

$Main_Title = $Form.findname("Main_Title") 
$Part1 = $Form.findname("Part1") 
$Part2 = $Form.findname("Part2") 
$Part3 = $Form.findname("Part3") 
$Part4 = $Form.findname("Part4") 

$OD_Migration_Btn_Previous = $Form.findname("OD_Migration_Btn_Previous") 
$OD_Migration_Btn_Next = $Form.findname("OD_Migration_Btn_Next") 
$Previous_Button = $Form.findname("Previous_Button") 
$Main_Buttons = $Form.findname("Main_Buttons") 
$FlipView = $Form.findname("FlipView") 
$Later_Btn = $Form.findname("Later_Btn") 

$FlipView.IsBannerEnabled = $false
$FlipView.IsNavigationEnabled = $false
$FlipView.LeftTransition = 0
$Main_Buttons.Margin = "-144,0,0,0"

$Extract_Folder_Path = "C:\Windows\Temp\BIOS_Extract"
$User_Continue_Process_File = "$Extract_Folder_Path\BIOS_Update_Continue.txt"

$Get_MTM = ((Get-CimInstance Win32_ComputerSystem).Model.SubString(0, 4)).Trim()
$Log_File = "$env:SystemDrive\Windows\Debug\Remediation_BIOS_Update_$Get_MTM.log"
If(!(Test-Path $Log_File)){ New-Item $Log_File -Type File -Force | Out-Null }

Function Write_Log {
    param($Message_Type, $Message)
    $MyDate = "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)
    Add-Content $Log_File "$MyDate - $Message_Type : $Message"
    Write-Host "$MyDate - $Message_Type : $Message"
}

Write_Log -Message_Type "INFO" -Message "Opening the user warning"

# ====================== IMPROVED POWER CHECK ======================
$OD_Migration_Btn_Next.Add_Click({
    If(($FlipView.SelectedIndex) -eq 0)
    {
        # Stronger Desktop + Power Detection
        $Computer = Get-CimInstance Win32_ComputerSystem
        $Manufacturer = $Computer.Manufacturer
        $Model = $Computer.Model

        $IsDesktop = ($Manufacturer -match "Lenovo") -and ($Model -match "ThinkCentre|ThinkStation|M Series|Desktop|P Series|Tower")

        # Multiple ways to detect AC Power
        $OnACPower = $true
        try {
            $Power = [System.Windows.Forms.SystemInformation]::PowerStatus
            if ($Power.PowerLineStatus -eq "Offline") { $OnACPower = $false }
        } catch {}

        # Fallback check
        if (-not $OnACPower) {
            try {
                $Battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
                if (-not $Battery) { $OnACPower = $true }  # No battery = Desktop
            } catch {}
        }

        Write_Log -Message_Type "INFO" -Message "Desktop: $IsDesktop | On AC: $OnACPower | Model: $Model"

        if ($IsDesktop -or $OnACPower)
        {
            Write_Log -Message_Type "INFO" -Message "Desktop or AC power detected - proceeding to update screen"
            ($FlipView.SelectedIndex) = 1
        }
        else
        {
            # Battery warning for real laptops only
            [MahApps.Metro.Controls.Dialogs.DialogManager]::ShowModalMessageExternal($Form,"Battery warning","Your device is running on battery.`nPlease connect the AC adapter to your PC to start the update.")
            Write_Log -Message_Type "INFO" -Message "Running on battery - warning shown"
        }
    }
    ElseIf(($FlipView.SelectedIndex) -eq 1)
    {			
        $okAndCancel = [MahApps.Metro.Controls.Dialogs.MessageDialogStyle]::AffirmativeAndNegative  
        $Button_Style = [MahApps.Metro.Controls.Dialogs.MetroDialogSettings]::new()
        $Button_Style.AffirmativeButtonText = "Update and restart"
        $Button_Style.NegativeButtonText = "Cancel"		

        $result = [MahApps.Metro.Controls.Dialogs.DialogManager]::ShowModalMessageExternal($Form,"Restart of your computer","A restart of your device is required to finalize the process.`n`nBy clicking on « Update and restart » your computer will restart in the next 5 minutes.`n`nDo not forget to save your work before clicking on Restart !",$okAndCancel, $Button_Style)   

        If($result -eq "Affirmative")
        {
            New-Item $User_Continue_Process_File -Type File -Force | Out-Null
            Start-Process -WindowStyle hidden powershell.exe "$Current_Folder\Update_BIOS.ps1" 
            Write_Log -Message_Type "INFO" -Message "User started the update process"										
            $Form.Close()			
        }		
    }
})

# Rest of your script remains the same
$FlipView.Add_SelectionChanged({ ... })   # Keep your existing code
$Later_Btn.Add_Click({ $Form.Close() })
$OD_Migration_Btn_Previous.Add_Click({ ... })  # Keep your existing code
$Form.Add_Closing({ ... })  # Keep your existing code

$Form.ShowDialog() | Out-Null